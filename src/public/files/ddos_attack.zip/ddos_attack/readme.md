1. Open the ddos.js file.  
2. Put the lien of your competitor in « http.get('https://exemple.com/'); » and save the file.  
3. Open terminal in this folder.  
4. Run this CMD « k6 run ddos.js ».  
   
