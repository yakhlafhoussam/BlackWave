import http from 'k6/http';
import { sleep } from 'k6';

export const options = {
  vus: 50000,
  duration: '1s',
};

export default function () {
  http.get('https://exemple.com/');
  sleep(0.1);
}
